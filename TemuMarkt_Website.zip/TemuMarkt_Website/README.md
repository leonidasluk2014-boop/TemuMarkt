# TemuMarkt – vollständige Flask-Web-App

## Funktionen
- Registrieren und Anmelden mit gehashten Passwörtern
- SQLite-Datenbank für Spieler, TC, Items, Bestellungen und Überweisungen
- 100 TC Startguthaben pro neuem Konto
- Shop mit Bestellfunktion; TC werden bei Bestellung reserviert/abgezogen
- Adminbereich: Artikel hinzufügen/bearbeiten/entfernen, Bestellungen annehmen/ablehnen, Kontostände ändern, Adminrechte vergeben
- Abgelehnte Bestellungen erstatten die TC zurück
- Überweisungen zwischen bestehenden Konten

## Lokal starten (Windows/macOS/Linux)
1. Python 3.10+ installieren.
2. Im Ordner ein Terminal öffnen.
3. Virtuelle Umgebung erstellen und Abhängigkeiten installieren:
   ```bash
   python -m venv .venv
   # Windows:
   .venv\\Scripts\\activate
   # macOS/Linux:
   source .venv/bin/activate
   pip install -r requirements.txt
   ```
4. Admin-Konto beim ersten Start konfigurieren. **Ein eigenes starkes Passwort verwenden**.
   Windows PowerShell:
   ```powershell
   $env:TEMUMARKT_ADMIN_USER="ShopAdmin"
   $env:TEMUMARKT_ADMIN_PASSWORD="DEIN-LANGES-EIGENES-PASSWORT"
   $env:TEMUMARKT_SECRET="EIN-LANGER-ZUFAELLIGER-ZUFALLSWERT"
   python app.py
   ```
   macOS/Linux:
   ```bash
   export TEMUMARKT_ADMIN_USER="ShopAdmin"
   export TEMUMARKT_ADMIN_PASSWORD="DEIN-LANGES-EIGENES-PASSWORT"
   export TEMUMARKT_SECRET="EIN-LANGER-ZUFAELLIGER-ZUFALLSWERT"
   python app.py
   ```
5. Browser öffnen: http://127.0.0.1:5000

Das Admin-Konto wird nur automatisch angelegt, wenn es noch nicht existiert und beide Admin-Variablen gesetzt sind. Andere Spieler registrieren sich über die Website und wählen ein eigenes Passwort.

## Öffentlich online stellen
Diese App braucht Hosting, das Python/Flask unterstützt. Für Produktion `requirements-production.txt` installieren und den Prozess über Gunicorn starten. `TEMUMARKT_SECRET`, `TEMUMARKT_ADMIN_USER` und `TEMUMARKT_ADMIN_PASSWORD` als geheime Umgebungsvariablen beim Hosting setzen. SQLite eignet sich für kleine private Communitys; bei mehreren App-Instanzen oder größeren Servern sollte eine verwaltete PostgreSQL-Datenbank verwendet werden. Persistenten Speicher für die Datenbank sicherstellen.

## Wichtige Hinweise
- Dies ist der vollständige Quellcode für eine serverbasierte App, aber noch keine öffentlich gehostete URL. Zum Livegang ist ein Hostingkonto nötig.
- Für eine öffentliche Website HTTPS aktivieren und vor dem Livegang Backup, Rate-Limits, CSRF-Schutz und Hosting-Konfiguration prüfen/ergänzen.
- Das gemeinsame Demo-Passwort aus der ursprünglichen Anfrage ist nicht als sicheres Passwortsystem geeignet. Spieler erstellen hier individuelle Konten. Das Adminpasswort sollte stark und privat bleiben.
