import os
import sqlite3
from functools import wraps
from flask import Flask, g, render_template, request, redirect, url_for, session, flash, abort
from werkzeug.security import generate_password_hash, check_password_hash

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("TEMUMARKT_DB", os.path.join(APP_DIR, "temumarkt.sqlite3"))
app = Flask(__name__)
app.secret_key = os.environ.get("TEMUMARKT_SECRET", "change-this-secret-before-deployment")
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax")

DEFAULT_ITEMS = [
    ("Eichenholz", "🪵", 8, "Solides Holz für Bauprojekte."),
    ("Stein", "🪨", 5, "Der Klassiker für jedes Bauwerk."),
    ("Diamant", "💎", 45, "Ein wertvoller Fund."),
    ("Goldblock", "🟨", 32, "Glänzender Block für besondere Builds."),
    ("TNT", "🧨", 18, "Mit Vorsicht zu verwenden."),
    ("Smaragd", "🟩", 28, "Perfekt für den Handel."),
    ("Obsidian", "⬛", 20, "Dunkel, robust und geheimnisvoll."),
    ("Kuchen", "🍰", 12, "Eine kleine Belohnung zwischendurch."),
]

def connect_db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    return con

def init_db():
    con = connect_db()
    con.executescript("""
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL UNIQUE COLLATE NOCASE,
      password_hash TEXT NOT NULL,
      coins INTEGER NOT NULL DEFAULT 100 CHECK(coins >= 0),
      is_admin INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      emoji TEXT NOT NULL DEFAULT '🧱',
      price INTEGER NOT NULL CHECK(price >= 0),
      description TEXT NOT NULL DEFAULT '',
      active INTEGER NOT NULL DEFAULT 1
    );
    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id),
      item_id INTEGER,
      item_name TEXT NOT NULL,
      emoji TEXT NOT NULL,
      price INTEGER NOT NULL,
      status TEXT NOT NULL DEFAULT 'Offen',
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS transfers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sender_id INTEGER NOT NULL REFERENCES users(id),
      receiver_id INTEGER NOT NULL REFERENCES users(id),
      amount INTEGER NOT NULL CHECK(amount > 0),
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    """)
    if con.execute("SELECT COUNT(*) FROM items").fetchone()[0] == 0:
        con.executemany("INSERT INTO items(name,emoji,price,description) VALUES(?,?,?,?)", DEFAULT_ITEMS)
    # Initial admin is provisioned from environment variables, never by being the first public registrant.
    admin_name = os.environ.get("TEMUMARKT_ADMIN_USER", "").strip()
    admin_password = os.environ.get("TEMUMARKT_ADMIN_PASSWORD", "")
    if admin_name and admin_password:
        existing = con.execute("SELECT id FROM users WHERE username = ?", (admin_name,)).fetchone()
        if not existing:
            con.execute("INSERT INTO users(username,password_hash,coins,is_admin) VALUES(?,?,100,1)",
                        (admin_name, generate_password_hash(admin_password)))
    con.commit()
    con.close()

@app.before_request
def load_user():
    g.user = None
    uid = session.get("user_id")
    if uid:
        con = connect_db()
        g.user = con.execute("SELECT id,username,coins,is_admin FROM users WHERE id=?", (uid,)).fetchone()
        con.close()
        if g.user is None:
            session.clear()

def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not g.user:
            flash("Bitte melde dich zuerst an.", "warning")
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapped

def admin_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not g.user:
            flash("Bitte melde dich zuerst an.", "warning")
            return redirect(url_for("login"))
        if not g.user["is_admin"]:
            abort(403)
        return fn(*args, **kwargs)
    return wrapped

@app.route("/")
def index():
    con = connect_db()
    items = con.execute("SELECT * FROM items WHERE active=1 ORDER BY name").fetchall()
    con.close()
    return render_template("index.html", items=items)

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if not (2 <= len(username) <= 20) or not all(c.isalnum() or c in "_-" for c in username):
            flash("Der Name muss 2–20 Zeichen haben (Buchstaben, Zahlen, _ oder -).", "error")
            return render_template("auth.html", mode="register")
        if len(password) < 8:
            flash("Das Passwort muss mindestens 8 Zeichen lang sein.", "error")
            return render_template("auth.html", mode="register")
        con = connect_db()
        try:
            con.execute("INSERT INTO users(username,password_hash,coins) VALUES(?,?,100)",
                        (username, generate_password_hash(password)))
            con.commit()
            user = con.execute("SELECT id FROM users WHERE username=?", (username,)).fetchone()
            session.clear()
            session["user_id"] = user["id"]
            flash("Konto erstellt! Du hast 100 TC Startguthaben erhalten.", "success")
            return redirect(url_for("account"))
        except sqlite3.IntegrityError:
            flash("Dieser Spielername ist bereits vergeben.", "error")
        finally:
            con.close()
    return render_template("auth.html", mode="register")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        con = connect_db()
        user = con.execute("SELECT * FROM users WHERE username=? COLLATE NOCASE", (username,)).fetchone()
        con.close()
        if not user or not check_password_hash(user["password_hash"], password):
            flash("Name oder Passwort ist falsch.", "error")
        else:
            session.clear()
            session["user_id"] = user["id"]
            flash("Du bist angemeldet.", "success")
            return redirect(url_for("account"))
    return render_template("auth.html", mode="login")

@app.post("/logout")
def logout():
    session.clear()
    flash("Du wurdest abgemeldet.", "success")
    return redirect(url_for("index"))

@app.route("/account")
@login_required
def account():
    con = connect_db()
    orders = con.execute("SELECT * FROM orders WHERE user_id=? ORDER BY id DESC", (g.user["id"],)).fetchall()
    sent = con.execute("""SELECT t.*,u.username AS receiver FROM transfers t JOIN users u ON u.id=t.receiver_id
                          WHERE t.sender_id=? ORDER BY t.id DESC LIMIT 10""", (g.user["id"],)).fetchall()
    received = con.execute("""SELECT t.*,u.username AS sender FROM transfers t JOIN users u ON u.id=t.sender_id
                              WHERE t.receiver_id=? ORDER BY t.id DESC LIMIT 10""", (g.user["id"],)).fetchall()
    con.close()
    return render_template("account.html", orders=orders, sent=sent, received=received)

@app.post("/buy/<int:item_id>")
@login_required
def buy(item_id):
    con = connect_db()
    try:
        con.execute("BEGIN IMMEDIATE")
        item = con.execute("SELECT * FROM items WHERE id=? AND active=1", (item_id,)).fetchone()
        user = con.execute("SELECT * FROM users WHERE id=?", (g.user["id"],)).fetchone()
        if not item:
            flash("Dieser Artikel ist nicht verfügbar.", "error")
        elif user["coins"] < item["price"]:
            flash("Du hast nicht genug TC.", "error")
        else:
            con.execute("UPDATE users SET coins=coins-? WHERE id=?", (item["price"], user["id"]))
            con.execute("INSERT INTO orders(user_id,item_id,item_name,emoji,price) VALUES(?,?,?,?,?)",
                        (user["id"], item["id"], item["name"], item["emoji"], item["price"]))
            flash("Bestellung wurde an die Verwaltung gesendet.", "success")
        con.commit()
    except Exception:
        con.rollback()
        raise
    finally:
        con.close()
    return redirect(url_for("index"))

@app.post("/transfer")
@login_required
def transfer():
    target_name = request.form.get("username", "").strip()
    try:
        amount = int(request.form.get("amount", "0"))
    except ValueError:
        amount = 0
    con = connect_db()
    try:
        con.execute("BEGIN IMMEDIATE")
        sender = con.execute("SELECT * FROM users WHERE id=?", (g.user["id"],)).fetchone()
        target = con.execute("SELECT * FROM users WHERE username=? COLLATE NOCASE", (target_name,)).fetchone()
        if not target or target["id"] == sender["id"]:
            flash("Bitte gib einen anderen existierenden Account an.", "error")
        elif amount < 1:
            flash("Der Betrag muss mindestens 1 TC sein.", "error")
        elif sender["coins"] < amount:
            flash("Du hast nicht genug TC.", "error")
        else:
            con.execute("UPDATE users SET coins=coins-? WHERE id=?", (amount, sender["id"]))
            con.execute("UPDATE users SET coins=coins+? WHERE id=?", (amount, target["id"]))
            con.execute("INSERT INTO transfers(sender_id,receiver_id,amount) VALUES(?,?,?)",
                        (sender["id"], target["id"], amount))
            flash(f"{amount} TC wurden an {target['username']} überwiesen.", "success")
        con.commit()
    except Exception:
        con.rollback()
        raise
    finally:
        con.close()
    return redirect(url_for("account"))

@app.route("/verwaltung")
@admin_required
def admin():
    con = connect_db()
    items = con.execute("SELECT * FROM items ORDER BY name").fetchall()
    users = con.execute("SELECT id,username,coins,is_admin FROM users ORDER BY username").fetchall()
    orders = con.execute("""SELECT o.*,u.username FROM orders o JOIN users u ON u.id=o.user_id ORDER BY o.id DESC""").fetchall()
    con.close()
    return render_template("admin.html", items=items, users=users, orders=orders)

@app.post("/verwaltung/item")
@admin_required
def save_item():
    item_id = request.form.get("id", "").strip()
    name = request.form.get("name", "").strip()
    emoji = request.form.get("emoji", "🧱").strip()[:8] or "🧱"
    desc = request.form.get("description", "").strip()[:200]
    try:
        price = int(request.form.get("price", "0"))
    except ValueError:
        price = -1
    if not name or price < 0 or len(name) > 60:
        flash("Bitte einen gültigen Namen und Preis eingeben.", "error")
        return redirect(url_for("admin"))
    con = connect_db()
    if item_id:
        con.execute("UPDATE items SET name=?,emoji=?,price=?,description=? WHERE id=?",
                    (name, emoji, price, desc, item_id))
    else:
        con.execute("INSERT INTO items(name,emoji,price,description) VALUES(?,?,?,?)", (name, emoji, price, desc))
    con.commit(); con.close()
    flash("Artikel gespeichert.", "success")
    return redirect(url_for("admin"))

@app.post("/verwaltung/item/<int:item_id>/delete")
@admin_required
def delete_item(item_id):
    con = connect_db()
    con.execute("UPDATE items SET active=0 WHERE id=?", (item_id,))
    con.commit(); con.close()
    flash("Artikel aus dem Shop entfernt.", "success")
    return redirect(url_for("admin"))

@app.post("/verwaltung/order/<int:order_id>")
@admin_required
def order_action(order_id):
    action = request.form.get("action")
    if action not in ("Angenommen", "Abgelehnt"):
        abort(400)
    con = connect_db()
    try:
        con.execute("BEGIN IMMEDIATE")
        order = con.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
        if not order:
            abort(404)
        if order["status"] == "Offen":
            if action == "Abgelehnt":
                con.execute("UPDATE users SET coins=coins+? WHERE id=?", (order["price"], order["user_id"]))
            con.execute("UPDATE orders SET status=? WHERE id=?", (action, order_id))
        con.commit()
    except Exception:
        con.rollback()
        raise
    finally:
        con.close()
    flash("Bestellstatus aktualisiert. Bei Ablehnung wurden TC zurückerstattet.", "success")
    return redirect(url_for("admin"))

@app.post("/verwaltung/user/<int:user_id>/admin")
@admin_required
def toggle_admin(user_id):
    if user_id == g.user["id"]:
        flash("Du kannst deine eigenen Adminrechte hier nicht ändern.", "error")
        return redirect(url_for("admin"))
    con = connect_db()
    target = con.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    if target:
        con.execute("UPDATE users SET is_admin=? WHERE id=?", (0 if target["is_admin"] else 1, user_id))
        con.commit()
    con.close()
    flash("Adminrechte aktualisiert.", "success")
    return redirect(url_for("admin"))

@app.post("/verwaltung/user/<int:user_id>/coins")
@admin_required
def adjust_coins(user_id):
    try:
        delta = int(request.form.get("delta", "0"))
    except ValueError:
        delta = 0
    con = connect_db()
    target = con.execute("SELECT coins FROM users WHERE id=?", (user_id,)).fetchone()
    if not target or target["coins"] + delta < 0:
        flash("Ungültige Kontostandsänderung.", "error")
    else:
        con.execute("UPDATE users SET coins=coins+? WHERE id=?", (delta, user_id))
        con.commit()
        flash("Kontostand angepasst.", "success")
    con.close()
    return redirect(url_for("admin"))

@app.errorhandler(403)
def forbidden(_):
    return render_template("error.html", code=403, message="Dieser Bereich ist nur für Admins."), 403

@app.errorhandler(404)
def not_found(_):
    return render_template("error.html", code=404, message="Diese Seite wurde nicht gefunden."), 404

init_db()
if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", "5000")), debug=False)
